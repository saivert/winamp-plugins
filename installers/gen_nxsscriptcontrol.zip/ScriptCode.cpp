// ScriptCode.cpp : Defines code to execute scripts using
// Microsoft Script Control

#include "StdAfx.h"

int RunScript(char *szScript)
{
	MessageBox(GetForegroundWindow(), "E_NOTIMPL", NULL, MB_OK|MB_ICONWARNING);
	return 0;
}

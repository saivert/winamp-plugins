// ScriptCode.h : Header file for ScriptCode.cpp
//

int RunScript(char *szScript);

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gen_nxsscriptcontrol.rc
//
#define IDS_EXECUTE                     1
#define IDS_HALT                        2
#define IDS_EXAMPLE1                    3
#define IDS_TIPABOUTPAGE                4
#define IDS_TIPSCRIPTPAGE               5
#define IDS_TIPGENERALPAGE              6
#define IDS_EXAMPLE2                    7
#define IDS_EXAMPLE3                    8
#define IDS_EXAMPLE4                    9
#define IDD_CONFIGPAGE                  103
#define IDD_ABOUT                       107
#define IDD_TITLEFORMAT                 108
#define IDD_SCRIPT                      108
#define IDD_GENERAL                     109
#define IDC_SCRIPTEDIT                  1000
#define IDC_RUNSCRIPT                   1001
#define IDC_CLEARSCRIPT                 1002
#define IDC_SAVETOFILE                  1003
#define IDC_LOADFROMFILE                1004
#define IDC_AUTHOR                      1005
#define IDC_LOGLIST                     1006
#define IDC_URLBUTTON                   1007
#define IDC_HOMEPAGE                    1007
#define IDC_LINKTOPAGE                  1007
#define IDC_HOMEPAGE2                   1008
#define IDC_SCLANGCOMBO                 1009
#define IDC_HOMEPAGE3                   1009
#define IDC_SCLANG                      1010
#define IDC_LOADSAMPLE                  1011
#define IDC_VERSION                     1012
#define IDC_SAMPLECOMBO                 1012
#define IDC_TAB1                        1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
